# Joker Store

Loja de likes e contas de Free Fire. Node puro, **sem dependências** (só precisa do Node 18+).

## Rodar no seu PC
```
node server.js
```
Abre em `http://localhost:3000`. O admin fica em `http://localhost:3000/admin`.

## Primeiro acesso
1. Entre no site e clique **Entrar → Criar conta**. **O primeiro cadastro vira o admin** (você).
2. Vá em `/admin`, logado com essa conta.
3. Em **Recebimento (Pix)**, coloque sua **chave Pix**, nome e cidade → salvar.
   A partir daí, todo pedido gera o **Pix copia-e-cola** automático.
4. Em **Produtos**, edite nome/preço/descrição, ligue/desligue, **coloque a foto** (galeria ou câmera) e crie novos.

## O que já funciona de verdade
- Cadastro e login com **senha criptografada** (scrypt), sessão por cookie.
- Produtos no banco (arquivos JSON na pasta `dados/`), editáveis no admin, com **foto**.
- Carrinho/pedido: cada compra cria um pedido e gera o **Pix copia-e-cola** válido (padrão do Banco Central).
- Painel admin: produtos, pedidos (muda status: aguardando → pago → entregue) e config do Pix.

## Pagamento e entrega (configurar no /admin)
Tudo isso é configurado no painel admin (ou por variável de ambiente). As chaves
ficam na pasta `dados/` (fora do git) — nunca no código.

- **Mercado Pago (Pix automático):** cole seu **Access Token** em Pagamento. Aí o Pix
  passa a gerar **QR + copia-e-cola** e **confirma sozinho**. Quando o pagamento é
  aprovado, o pedido é marcado pago e, se for produto de like, **a entrega sai na hora**.
  - Pra confirmação instantânea, cadastre a URL de webhook no painel do Mercado Pago:
    `https://SEU-DOMINIO/api/webhook/mercadopago`. (Mesmo sem webhook, o app fica
    checando o status e confirma em alguns segundos.)
  - Env equivalente: `MP_TOKEN`.
- **Binance:** coloque sua **Binance Pay ID / email**. O cliente paga por ela e você
  confirma no admin (mudando o status pra "pago"). Env: `BINANCE_ID`.
- **API de likes (a mesma do autolikesystem — Source):** em "API de likes" ponha o
  endereço e a **senha** (`X-Api-Password`). Com isso, produto de like com
  "Likes a entregar" > 0 é **entregue automático** quando o pedido é pago
  (`GET /like?id=<uid>&region=BR&token=<qtd>`). Env: `SOURCE_BASE`, `SOURCE_SENHA`.
- **Pix manual (reserva):** se não quiser o Mercado Pago, dá pra usar uma chave Pix
  simples — gera o copia-e-cola e você confirma no admin.

Observação: produtos que não são de like (contas, passe, codiguin, craft) entram como
"pago" e você entrega manual. Autolike recorrente (todo dia) é um passo a mais (um
agendador), dá pra ligar depois.

## Subir no Square Cloud
- Já tem o `squarecloud.config` (MAIN=server.js). Suba a pasta zipada ou por git.
- **Importante:** a pasta `dados/` guarda contas, produtos e pedidos. No Square Cloud, aponte
  um **volume persistente** pra ela (ou ela reseta a cada deploy). Se precisar, eu ajusto o
  caminho dos dados pra uma variável de ambiente.

## Estrutura
- `server.js` — o servidor e toda a API.
- `public/index.html` — a loja (landing + login + área do cliente).
- `public/admin.html` — o painel do dono.
- `dados/` — banco em JSON (criado sozinho).
