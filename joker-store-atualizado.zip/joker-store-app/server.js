'use strict';
// ════════════════════════════════════════════════════════════════════════════
// JOKER STORE — servidor (Node puro, sem dependências).
// Contas (senha criptografada), produtos, carteira, pedidos com Pix
// copia-e-cola, e painel admin. Dados em arquivos JSON na pasta dados/.
// Sobe com:  node server.js   (porta 3000 ou process.env.PORT)
// ════════════════════════════════════════════════════════════════════════════
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const RAIZ = __dirname;
const DADOS = path.join(RAIZ, 'dados');
const PUB = path.join(RAIZ, 'public');
const PORTA = Number(process.env.PORT) || 3000;
if (!fs.existsSync(DADOS)) fs.mkdirSync(DADOS, { recursive: true });

// ── banco simples em JSON ───────────────────────────────────────────────────
function ler(nome, padrao) {
  try { return JSON.parse(fs.readFileSync(path.join(DADOS, nome), 'utf8')); }
  catch (_) { return padrao; }
}
function salvar(nome, valor) {
  const tmp = path.join(DADOS, nome + '.tmp');
  fs.writeFileSync(tmp, JSON.stringify(valor, null, 2));
  fs.renameSync(tmp, path.join(DADOS, nome));
}
const db = {
  usuarios: ler('usuarios.json', []),
  produtos: ler('produtos.json', null),
  pedidos: ler('pedidos.json', []),
  config: ler('config.json', null),
};

// ── config (chave Pix, nome do recebedor) — o admin edita ───────────────────
if (!db.config) {
  db.config = {
    pix_chave: '',            // sua chave Pix (email, telefone, CPF/CNPJ ou aleatória) — usada no Pix manual
    pix_nome: 'JOKER STORE',  // nome do recebedor (máx 25)
    pix_cidade: 'SAO PAULO',  // cidade (máx 15)
    mp_token: '',             // Mercado Pago: Access Token (Pix que confirma sozinho)
    binance_id: '',           // Binance: seu Pay ID / email pra receber (confirmação manual no admin)
    source_base: 'https://likesffggx.squareweb.app', // API de likes (a mesma do autolikesystem)
    source_senha: '',         // senha da Source (X-Api-Password)
    segredo: crypto.randomBytes(24).toString('hex'), // assina os cookies de sessão
  };
  salvar('config.json', db.config);
}
// garante campos novos em config antigo
['mp_token', 'binance_id', 'source_base', 'source_senha'].forEach((k) => { if (db.config[k] === undefined) db.config[k] = k === 'source_base' ? 'https://likesffggx.squareweb.app' : ''; });
// ambiente tem prioridade sobre o painel (bom pro Square Cloud)
const cfg = (k) => process.env[k.toUpperCase()] || db.config[k] || '';

// ── produtos iniciais (os seus) ─────────────────────────────────────────────
if (!db.produtos) {
  db.produtos = [
    { id: 'a220', nome: 'Autolike 220', cat: 'likes', ic: 's-bolt', preco_cent: 990, tag: 'TOP', ativo: true, foto: '', entrega_qtd: 220, desc: '220 likes todo dia no seu Free Fire, no automático. Cadastra o ID uma vez e deixa rodar.' },
    { id: 'a5001000', nome: 'Autolike 500/1000', cat: 'likes', ic: 's-bolt', preco_cent: 1990, ativo: true, foto: '', entrega_qtd: 1000, desc: '500 ou 1000 likes por dia, automático. Pra quem quer subir mais rápido.' },
    { id: 'rev2k', nome: '2K de likes · Revendedor', cat: 'likes', ic: 's-wallet', preco_cent: 900, tag: 'REVENDA', ativo: true, foto: '', entrega_qtd: 2000, desc: '2.000 likes de uma vez no preço de revenda. Compre a R$9 e venda pros seus clientes.' },
    { id: 'guest', nome: 'Contas Guest com skin', cat: 'contas', ic: 's-id', preco_cent: 490, ativo: true, foto: '', entrega_qtd: 0, desc: 'Contas guest que já vêm com skin. Pronta pra usar na hora.' },
    { id: 'ffpremium', nome: 'Contas FF · muitas skins', cat: 'contas', ic: 's-id', preco_cent: 4990, tag: 'PREMIUM', ativo: true, foto: '', entrega_qtd: 0, desc: 'Contas cheias de skin, raras e de evento. As mais fortes da loja.' },
    { id: 'passe', nome: 'Passe de Elite', cat: 'ff', ic: 's-id', preco_cent: 1490, ativo: true, foto: '', entrega_qtd: 0, desc: 'Libera o Passe de Elite da temporada direto no seu ID.' },
    { id: 'codiguin', nome: 'Codiguin do Free Fire', cat: 'ff', ic: 's-bag', preco_cent: 790, ativo: true, foto: '', entrega_qtd: 0, desc: 'Códigos (codiguin) pra resgatar recompensas no jogo.' },
    { id: 'craft', nome: 'Craft Land', cat: 'ff', ic: 's-bag', preco_cent: 1290, ativo: true, foto: '', entrega_qtd: 0, desc: 'Craft Land pra você montar e brincar do seu jeito.' },
  ];
  salvar('produtos.json', db.produtos);
}

// ── senha: scrypt + salt (nada de senha em texto puro) ──────────────────────
function criarHash(senha) {
  const salt = crypto.randomBytes(16).toString('hex');
  const dk = crypto.scryptSync(String(senha), salt, 32).toString('hex');
  return salt + ':' + dk;
}
function confereHash(senha, hash) {
  try {
    const [salt, dk] = String(hash).split(':');
    const teste = crypto.scryptSync(String(senha), salt, 32);
    return crypto.timingSafeEqual(Buffer.from(dk, 'hex'), teste);
  } catch (_) { return false; }
}

// ── sessão por cookie assinado (userId.assinatura) ──────────────────────────
function assinar(valor) {
  const h = crypto.createHmac('sha256', db.config.segredo).update(valor).digest('hex').slice(0, 24);
  return valor + '.' + h;
}
function lerCookie(req) {
  const c = {};
  (req.headers.cookie || '').split(';').forEach((p) => {
    const i = p.indexOf('='); if (i < 0) return;
    c[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return c;
}
function usuarioDaReq(req) {
  const t = lerCookie(req).js_sessao;
  if (!t) return null;
  const i = t.lastIndexOf('.'); if (i < 0) return null;
  const id = t.slice(0, i);
  if (assinar(id) !== t) return null;
  return db.usuarios.find((u) => u.id === id) || null;
}

// ── respostas ───────────────────────────────────────────────────────────────
function json(res, cod, obj, cookies) {
  const h = { 'Content-Type': 'application/json; charset=utf-8' };
  if (cookies) h['Set-Cookie'] = cookies;
  res.writeHead(cod, h);
  res.end(JSON.stringify(obj));
}
function corpo(req) {
  return new Promise((resolve) => {
    let d = ''; req.on('data', (c) => { d += c; if (d.length > 8e6) req.destroy(); });
    req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch (_) { resolve({}); } });
  });
}
const publicoUsuario = (u) => ({ id: u.id, usuario: u.usuario, admin: !!u.admin, saldo_cent: u.saldo_cent || 0, revendedor: !!u.revendedor, ids: u.ids || [] });

// ── Pix copia-e-cola (BR Code EMV) — padrão do Banco Central, sem API ───────
function campo(id, valor) { const s = String(valor); return id + String(s.length).padStart(2, '0') + s; }
function crc16(str) {
  let crc = 0xFFFF;
  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) & 0xFFFF : (crc << 1) & 0xFFFF;
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}
function limpa(s, n) { return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9 ]/g, '').toUpperCase().slice(0, n).trim(); }
function pixCopiaECola(valorCent, txid) {
  const chave = db.config.pix_chave;
  if (!chave) return null; // sem chave Pix configurada no admin
  const mai = campo('00', 'br.gov.bcb.pix') + campo('01', chave);
  let p = '';
  p += campo('00', '01');
  p += campo('26', mai);
  p += campo('52', '0000');
  p += campo('53', '986');
  p += campo('54', (valorCent / 100).toFixed(2));
  p += campo('58', 'BR');
  p += campo('59', limpa(db.config.pix_nome, 25) || 'JOKER STORE');
  p += campo('60', limpa(db.config.pix_cidade, 15) || 'SAO PAULO');
  p += campo('62', campo('05', limpa(txid, 25) || '***'));
  p += '6304';
  return p + crc16(p);
}

// ── MERCADO PAGO (Pix que confirma sozinho) ─────────────────────────────────
// Usa o Access Token da sua conta Mercado Pago (painel admin ou env MP_TOKEN).
// Cria um pagamento Pix e devolve o copia-e-cola + QR; a confirmação vem pelo
// webhook /api/webhook/mercadopago ou pela checagem /api/pedido-status.
async function mpCriarPix(pedido) {
  const token = cfg('mp_token'); if (!token) return null;
  const r = await fetch('https://api.mercadopago.com/v1/payments', {
    method: 'POST',
    headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json', 'X-Idempotency-Key': pedido.id },
    body: JSON.stringify({
      transaction_amount: Number((pedido.valor_cent / 100).toFixed(2)),
      description: pedido.produto_nome,
      payment_method_id: 'pix',
      external_reference: pedido.id,
      payer: { email: (pedido.email || ('cliente+' + pedido.id + '@jokerstore.app')) },
    }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.id) return { erro: (j && (j.message || j.error)) || 'falha ao criar Pix no Mercado Pago' };
  const td = (j.point_of_interaction && j.point_of_interaction.transaction_data) || {};
  return { mp_id: String(j.id), status: j.status, copia_cola: td.qr_code || '', qr_base64: td.qr_code_base64 || '' };
}
async function mpStatus(mpId) {
  const token = cfg('mp_token'); if (!token || !mpId) return null;
  const r = await fetch('https://api.mercadopago.com/v1/payments/' + mpId, { headers: { 'Authorization': 'Bearer ' + token } });
  const j = await r.json().catch(() => ({}));
  return j && j.status ? j.status : null; // approved, pending, rejected...
}

// ── ENTREGA DE LIKES (a mesma API do autolikesystem: Source) ────────────────
// GET {base}/like?id=<uid>&region=BR&token=<qtd>  com header X-Api-Password.
async function entregarLikes(pedido, prod) {
  const base = cfg('source_base'), senha = cfg('source_senha');
  if (!base || !senha) return { ok: false, erro: 'API de likes não configurada (base/senha)' };
  if (!pedido.uid_jogo) return { ok: false, erro: 'faltou o ID do jogador no pedido' };
  const qtd = Math.max(1, Number(prod.entrega_qtd) || 0);
  const u = new URL(base.replace(/\/+$/, '') + '/like');
  u.searchParams.set('id', pedido.uid_jogo);
  u.searchParams.set('region', 'BR');
  if (qtd > 0) u.searchParams.set('token', String(qtd));
  u.searchParams.set('priority', 'interactive');
  const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 80000);
  try {
    const r = await fetch(u.toString(), { headers: { 'X-Api-Password': senha }, signal: ctrl.signal });
    const j = await r.json().catch(() => ({}));
    const res = j.result || {};
    const info = res.LikeInfo || res.likeInfo || {};
    const entrou = (info.LikesAfter != null && info.LikesBefore != null) ? Math.max(0, info.LikesAfter - info.LikesBefore) : (info.LikesGivenByAPI || 0);
    return { ok: r.ok, entrou, nick: res.NickName || null, bruto: res };
  } catch (e) { return { ok: false, erro: e.message }; } finally { clearTimeout(t); }
}

// marca pago e, se for produto de like, entrega na hora
async function pagarEEntregar(pedido) {
  if (pedido.status === 'entregue') return pedido;
  pedido.status = 'pago'; pedido.pago_em = new Date().toISOString();
  const prod = db.produtos.find((x) => x.id === pedido.produto_id);
  if (prod && prod.cat === 'likes' && Number(prod.entrega_qtd) > 0) {
    const ent = await entregarLikes(pedido, prod);
    pedido.entrega = ent;
    if (ent.ok) { pedido.status = 'entregue'; pedido.entregue_em = new Date().toISOString(); }
  }
  salvar('pedidos.json', db.pedidos);
  return pedido;
}

// ── estáticos ───────────────────────────────────────────────────────────────
const TIPOS = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
function servirArquivo(res, arquivo) {
  const alvo = path.join(PUB, arquivo);
  if (!alvo.startsWith(PUB) || !fs.existsSync(alvo) || !fs.statSync(alvo).isFile()) return false;
  res.writeHead(200, { 'Content-Type': TIPOS[path.extname(alvo)] || 'application/octet-stream' });
  res.end(fs.readFileSync(alvo));
  return true;
}

// ── roteador ────────────────────────────────────────────────────────────────
const servidor = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  const metodo = req.method;

  // API
  if (p.startsWith('/api/')) {
    const eu = usuarioDaReq(req);

    if (p === '/api/eu') return json(res, 200, { ok: true, usuario: eu ? publicoUsuario(eu) : null });

    if (p === '/api/produtos') {
      const lista = db.produtos.filter((x) => x.ativo).map((x) => ({ id: x.id, nome: x.nome, cat: x.cat, ic: x.ic, preco_cent: x.preco_cent, tag: x.tag || '', foto: x.foto || '', desc: x.desc || '' }));
      return json(res, 200, { ok: true, produtos: lista });
    }

    if (p === '/api/registrar' && metodo === 'POST') {
      const b = await corpo(req);
      const usuario = String(b.usuario || '').trim();
      const senha = String(b.senha || '');
      if (usuario.length < 3) return json(res, 400, { ok: false, erro: 'usuário precisa de ao menos 3 letras' });
      if (senha.length < 4) return json(res, 400, { ok: false, erro: 'senha precisa de ao menos 4 caracteres' });
      if (db.usuarios.some((u) => u.usuario.toLowerCase() === usuario.toLowerCase())) return json(res, 409, { ok: false, erro: 'esse usuário já existe' });
      const u = { id: crypto.randomBytes(8).toString('hex'), usuario, hash: criarHash(senha), admin: db.usuarios.length === 0, saldo_cent: 0, revendedor: false, ids: [], criado: new Date().toISOString() };
      db.usuarios.push(u); salvar('usuarios.json', db.usuarios);
      // o PRIMEIRO cadastro vira admin (você). Os próximos são clientes.
      return json(res, 200, { ok: true, usuario: publicoUsuario(u) }, [cookieSessao(u.id)]);
    }

    if (p === '/api/entrar' && metodo === 'POST') {
      const b = await corpo(req);
      const u = db.usuarios.find((x) => x.usuario.toLowerCase() === String(b.usuario || '').trim().toLowerCase());
      if (!u || !confereHash(String(b.senha || ''), u.hash)) return json(res, 401, { ok: false, erro: 'usuário ou senha errados' });
      return json(res, 200, { ok: true, usuario: publicoUsuario(u) }, [cookieSessao(u.id)]);
    }

    if (p === '/api/sair' && metodo === 'POST') {
      return json(res, 200, { ok: true }, ['js_sessao=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax']);
    }

    // WEBHOOK do Mercado Pago (público; configure a URL no painel do MP).
    // Quando o pagamento é aprovado, marca o pedido como pago e entrega o like.
    if (p === '/api/webhook/mercadopago') {
      let id = url.searchParams.get('data.id') || url.searchParams.get('id');
      let tipo = url.searchParams.get('type') || url.searchParams.get('topic');
      if (metodo === 'POST') { const b = await corpo(req); if (b && b.data && b.data.id) id = String(b.data.id); if (b && b.type) tipo = b.type; }
      if (id && (!tipo || tipo === 'payment')) {
        const st = await mpStatus(id).catch(() => null);
        if (st === 'approved') { const pd = db.pedidos.find((x) => x.mp_id === String(id)); if (pd && pd.status === 'aguardando') await pagarEEntregar(pd); }
      }
      return json(res, 200, { ok: true });
    }

    // precisa estar logado daqui pra baixo
    if (!eu) return json(res, 401, { ok: false, erro: 'faça login' });

    if (p === '/api/meus-pedidos') {
      return json(res, 200, { ok: true, pedidos: db.pedidos.filter((pd) => pd.usuario_id === eu.id).sort((a, b) => b.criado.localeCompare(a.criado)) });
    }

    // cria pedido + pagamento (Pix via Mercado Pago, ou Binance manual)
    if (p === '/api/pedido' && metodo === 'POST') {
      const b = await corpo(req);
      const prod = db.produtos.find((x) => x.id === b.produto_id && x.ativo);
      if (!prod) return json(res, 404, { ok: false, erro: 'produto indisponível' });
      const metodoPg = (b.metodo === 'binance') ? 'binance' : 'pix';
      const txid = 'JK' + Date.now().toString(36).toUpperCase();
      const pedido = { id: crypto.randomBytes(6).toString('hex'), txid, usuario_id: eu.id, produto_id: prod.id, produto_nome: prod.nome, valor_cent: prod.preco_cent, uid_jogo: String(b.uid || '').replace(/\D/g, '').slice(0, 20), metodo: metodoPg, status: 'aguardando', criado: new Date().toISOString() };
      db.pedidos.push(pedido);
      const resp = { ok: true, pedido, metodo: metodoPg };
      if (metodoPg === 'pix') {
        const mp = await mpCriarPix(pedido).catch(() => null);
        if (mp && mp.copia_cola) { pedido.mp_id = mp.mp_id; resp.pix = mp.copia_cola; resp.qr_base64 = mp.qr_base64; resp.auto = true; resp.pix_configurado = true; }
        else { const pix = pixCopiaECola(prod.preco_cent, txid); pedido.pix = pix || ''; resp.pix = pix || ''; resp.auto = false; resp.pix_configurado = !!pix; if (mp && mp.erro) resp.aviso = 'Mercado Pago não configurado — usando Pix manual.'; }
      } else {
        resp.binance_id = cfg('binance_id'); resp.binance_configurado = !!cfg('binance_id');
      }
      salvar('pedidos.json', db.pedidos);
      return json(res, 200, resp);
    }

    // checa se o pedido já foi pago (consulta o Mercado Pago)
    if (p === '/api/pedido-status') {
      const pd = db.pedidos.find((x) => x.id === url.searchParams.get('id') && x.usuario_id === eu.id);
      if (!pd) return json(res, 404, { ok: false, erro: 'pedido não encontrado' });
      if (pd.status === 'aguardando' && pd.mp_id) {
        const st = await mpStatus(pd.mp_id).catch(() => null);
        if (st === 'approved') await pagarEEntregar(pd);
        else if (st === 'rejected' || st === 'cancelled') { pd.status = 'cancelado'; salvar('pedidos.json', db.pedidos); }
      }
      return json(res, 200, { ok: true, status: pd.status, entrega: pd.entrega || null });
    }

    // ── ADMIN ──
    if (p.startsWith('/api/admin/')) {
      if (!eu.admin) return json(res, 403, { ok: false, erro: 'só admin' });

      if (p === '/api/admin/resumo') {
        return json(res, 200, { ok: true, produtos: db.produtos, pedidos: db.pedidos.slice(-50).reverse(), usuarios: db.usuarios.length,
          config: { pix_chave: db.config.pix_chave, pix_nome: db.config.pix_nome, pix_cidade: db.config.pix_cidade,
            binance_id: db.config.binance_id, source_base: db.config.source_base,
            mp_ok: !!cfg('mp_token'), source_ok: !!cfg('source_senha') } });
      }
      if (p === '/api/admin/config' && metodo === 'POST') {
        const b = await corpo(req);
        ['pix_chave', 'pix_nome', 'pix_cidade', 'binance_id', 'source_base'].forEach((k) => { if (b[k] !== undefined) db.config[k] = String(b[k]).trim(); });
        // segredos: só grava se mandou algo (deixa em branco = mantém)
        if (b.mp_token) db.config.mp_token = String(b.mp_token).trim();
        if (b.source_senha) db.config.source_senha = String(b.source_senha).trim();
        if (b.limpar_mp) db.config.mp_token = '';
        if (b.limpar_source) db.config.source_senha = '';
        salvar('config.json', db.config);
        return json(res, 200, { ok: true });
      }
      if (p === '/api/admin/produto' && metodo === 'POST') {
        const b = await corpo(req);
        let prod = db.produtos.find((x) => x.id === b.id);
        if (!prod) { prod = { id: b.id || ('p' + crypto.randomBytes(4).toString('hex')), ativo: true, cat: 'likes', ic: 's-bag', foto: '' }; db.produtos.push(prod); }
        ['nome', 'cat', 'ic', 'tag', 'desc', 'foto'].forEach((k) => { if (b[k] !== undefined) prod[k] = b[k]; });
        if (b.preco_cent !== undefined) prod.preco_cent = Math.max(0, Math.round(Number(b.preco_cent) || 0));
        if (b.entrega_qtd !== undefined) prod.entrega_qtd = Math.max(0, Math.round(Number(b.entrega_qtd) || 0));
        if (b.ativo !== undefined) prod.ativo = !!b.ativo;
        salvar('produtos.json', db.produtos);
        return json(res, 200, { ok: true, produto: prod });
      }
      if (p === '/api/admin/produto-apagar' && metodo === 'POST') {
        const b = await corpo(req);
        db.produtos = db.produtos.filter((x) => x.id !== b.id); salvar('produtos.json', db.produtos);
        return json(res, 200, { ok: true });
      }
      // marca pedido pago (até o Pix automático existir, você confirma aqui)
      if (p === '/api/admin/pedido-status' && metodo === 'POST') {
        const b = await corpo(req);
        const pd = db.pedidos.find((x) => x.id === b.id);
        if (!pd) return json(res, 404, { ok: false, erro: 'pedido não encontrado' });
        pd.status = String(b.status || 'pago');
        salvar('pedidos.json', db.pedidos);
        return json(res, 200, { ok: true, pedido: pd });
      }
      return json(res, 404, { ok: false, erro: 'rota admin não encontrada' });
    }

    return json(res, 404, { ok: false, erro: 'rota não encontrada' });
  }

  // páginas
  if (p === '/' ) { servirArquivo(res, 'index.html'); return; }
  if (p === '/admin') { servirArquivo(res, 'admin.html'); return; }
  const limpo = decodeURIComponent(p.replace(/^\/+/, ''));
  if (servirArquivo(res, limpo)) return;
  // SPA fallback
  servirArquivo(res, 'index.html');
});

function cookieSessao(id) {
  return 'js_sessao=' + encodeURIComponent(assinar(id)) + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=' + (60 * 60 * 24 * 30);
}

servidor.listen(PORTA, () => {
  console.log('[joker-store] no ar em http://localhost:' + PORTA);
  console.log('[joker-store] admin em /admin (o 1º cadastro vira admin)');
  if (!db.config.pix_chave) console.log('[joker-store] configure sua chave Pix no painel admin pra gerar o copia-e-cola');
});
